import acm.program.ConsoleProgram;


public class Moon extends ConsoleProgram {

	
	public void run() {
		
	}
}
