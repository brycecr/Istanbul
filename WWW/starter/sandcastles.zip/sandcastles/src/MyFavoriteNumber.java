import acm.program.ConsoleProgram;

public class MyFavoriteNumber extends ConsoleProgram {

	public void run() {
		int guess = readInt("What do you think my favorite number is? ");

	}
	
	//write a method here that returns whether a given number is your favorite number
	//use this method in your run() method

}
