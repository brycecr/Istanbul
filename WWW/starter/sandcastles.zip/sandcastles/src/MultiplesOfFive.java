import acm.program.ConsoleProgram;


public class MultiplesOfFive extends ConsoleProgram {

	private static final int NUM_TO_PRINT = 10;

	public void run() {

	}
	
}
