import acm.program.ConsoleProgram;
import acm.util.RandomGenerator;


public class RandomNumberGuesser extends ConsoleProgram {

	RandomGenerator rg = RandomGenerator.getInstance();
	
	public void run() {

	}

}
