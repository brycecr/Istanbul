import stanford.karel.*;

public class PaintDiagonal extends SuperKarel {
	
	public void run() {

	}
}
