import acm.program.ConsoleProgram;


public class TaxCalculator extends ConsoleProgram {

	private static final int CUTOFF = 20000;
	private static final double LOW_TAX = .15;
	private static final double HIGH_TAX = .2;
	
	public void run() {
		int income = readInt("Enter an income: ");
		//Compute how much tax (TL) is due for this income.
	}
	
	//Write a method here that returns the percent income tax for a *given* income
	//Use this method in run()
	
}
