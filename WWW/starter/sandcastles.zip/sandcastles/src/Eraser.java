import java.awt.event.MouseEvent;
import java.awt.Color;

import acm.graphics.*;
import acm.program.GraphicsProgram;


public class Eraser extends GraphicsProgram {
	public void run() {
		
	}
	
}
