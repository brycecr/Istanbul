import acm.program.ConsoleProgram;
import acm.util.RandomGenerator;


public class GenerateRandomNumbers extends ConsoleProgram {

	private static int NUMBER_OF_RANDOMS = 30;
	RandomGenerator rg = RandomGenerator.getInstance();
	
	public void run() {
		println(NUMBER_OF_RANDOMS + " random numbers:");
		
	}
	
}
