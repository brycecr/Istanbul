import acm.program.ConsoleProgram;


public class ComputeSum extends ConsoleProgram {

	public void run() {
		
	}
}
