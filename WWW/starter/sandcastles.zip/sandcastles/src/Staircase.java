import java.awt.Color;

import acm.graphics.GOval;
import acm.program.GraphicsProgram;

public class Staircase extends GraphicsProgram {

	private static final int STEP_WIDTH = 100;
	private static final int STEP_HEIGHT = 50;
	
	public void run() {
		
		
	}
}
