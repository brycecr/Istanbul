import java.awt.Color;
import java.util.ArrayList;

import acm.graphics.GOval;
import acm.program.GraphicsProgram;

public class GrowingGOvals extends GraphicsProgram {

	public static final int APPLICATION_WIDTH = 750;
	public static final int APPLICATION_HEIGHT = 500;
	private static final int NUM_OVALS = 5;
	private static final int INITIAL_OVAL_DIAMETER = 100;
	private static final int GAP = 20;
	
	private static final int DELAY = 15;
	
	public void run() {
		
	}
}
