import subprocess
import os.path

print '-----------------------------------------'
print 'Welcome to the CS221 project 3 installer.'
print 'In order to make your project easier to program,'
print 'and to allow you to visualize what you are doing'
print 'we are going to use some basic python tools'
print '-----------------------------------------'
print ''

#for pc users
#runas /noprofile /user:Administrator cmd

pluginDir = 'plugins'
setupToolsDir = os.path.join(pluginDir, 'setuptools')
easyInstallPath = os.path.join(setupToolsDir, 'easy_install.py')

print '(1/ 2) Installing numpy:'
subprocess.call(['sudo', 'python', easyInstallPath, 'numpy'])


print ''
print '(2/ 2) Installing matplotlib'
subprocess.call(['sudo', 'python', easyInstallPath, 'matplotlib'])


