
:mod:`matplotlib.backends.backend_qt4agg`
=========================================

.. automodule:: matplotlib.backends.backend_qt4agg
   :members:
   :undoc-members:
   :show-inheritance:

