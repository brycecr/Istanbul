********
mathtext
********

.. inheritance-diagram:: matplotlib.mathtext
   :parts: 1

:mod:`matplotlib.mathtext`
=============================

.. automodule:: matplotlib.mathtext
   :members:
   :undoc-members:
   :show-inheritance:
