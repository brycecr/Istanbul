matplotlib is a python 2D plotting library which produces publication
quality figures in a variety of hardcopy formats and interactive
environments across platforms. matplotlib can be used in python
scripts, the python and ipython shell (ala matlab or mathematica), web
application servers, and various graphical user interface toolkits.

Home page: <http://matplotlib.org/>

For installation instructions and requirements, see the INSTALL file.
