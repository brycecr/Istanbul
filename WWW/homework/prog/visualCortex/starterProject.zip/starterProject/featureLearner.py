'''
File: Classifier
----------------
This is your file to modify! You should fill in both
the learn and extractFeatures functions. 
'''

import util
import numpy as np

PATCH_LENGTH = 64

class FeatureLearner(object):

    # Constructor
    # -----------
    # Called when the classifier is first created.
    def __init__(self, k):
        #DON"T CHANGE THIS. USED FOR GRADING
        self.maxIter = 50
        self.trained = False
        self.k = k
        self.centroids = None

    # Function: Run K Means
    # -------------
    # Given a set of training images, and a number of features
    # to learn self.k number of centroids. This 
    # function will be called only once. It does not return
    # a value. Instead this function fills in self.centroids.
    def runKmeans(self, trainImages):
        assert not self.trained

        # This line starts you out with random patches which 
        # are stored in a matrix with 64 rows and k columsn. 
        # Each col is a patch.
        # Each patch has 64 values.
        self.centroids = np.random.randn(PATCH_LENGTH, self.k)

        ### YOUR CODE HERE ###

        self.trained = True

    # Function: Extract Features
    # -------------
    # Given an image, extract and return its features. This
    # function will be called many times. Should return a 1-d
    # feature array that is number of patches by number of
    # centroids long. Assume that k-means has already been 
    # run.
    def extractFeatures(self, image):
        assert self.trained

        # populate features with features for each patch
        # of the image. 
        features = np.zeros((len(image.getPatches)*self.k))

        ### YOUR CODE HERE ###

        return features
